import { styled } from "styled-components";

export const PostHeaderContainer = styled.section`
    width: 100%;
    height: 10.5rem;
    background: ${({theme }) => theme.colors["base-profile"]};
    margin-top: -5.5rem;
    display: flex;
    border-radius: 10px;
    box-shadow: 0px 2px 28px rgba(0, 0, 0, 0.2);
    max-width: 54rem;
    padding: 2rem 2rem;
    flex-direction: column;

    header {
        display: flex;
        justify-content: space-between;
        width: 100%;
        margin-bottom: 1.25rem;
    }

    h1 {
        font-size: ${({ theme }) => theme.textSizes["title-title-l"]};
        color: ${({ theme }) => theme.colors["base-title"]};
        margin-bottom: 0.5rem;
    }

    ul {
        display: flex;
        align-items: center;
        gap: 2rem;
        flex-wrap: wrap;

        li {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: ${({ theme }) => theme.colors["base-span"]}

            svg {
                color: ${({ theme }) => theme.colors["base-label"]}
            }
        }
    }
`