import { PostInterface } from "../../";
import { PostsContainer } from "./styles";

interface PostProps {
    post: PostInterface
}

export function Posts({ post }: PostProps) {
    return (
        <PostsContainer to={`/post/${post.number}`}>
            <div>
                <strong>{post.title}</strong>
                <span>{post.created_at}</span>
            </div>
            <p>
                {post.body}
            </p>
        </PostsContainer>
    )
}