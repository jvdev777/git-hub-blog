import { styled } from "styled-components";

export const ExternalLinksContainer = styled.a`
    color: ${({ theme }) => theme.colors["blue"]};
    text-transform: uppercase;
    font-size: ${({theme}) => theme.textSizes["components-link"]};
    font-weight: 700;
    display: flex;
    align-items: center;
    border-bottom: 1px solid transparent;
    height: 19px;
    line-height: 19px;
    gap: 0.5rem;
    transition: 0.4s

    svg {
        width: 0.75rem;
        height: 0.75rem
    }

    &:hover {
        border-color: ${({ theme }) => theme.colors["blue"]}
    }
`